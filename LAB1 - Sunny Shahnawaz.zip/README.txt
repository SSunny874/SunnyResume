Hello!

The following are instructions on how to open my resume webpage locally:
1. Extract the contents of the zip file into a different folder to view the webpage.
1. Drag and drop the .html file into a web browser of your choice.
2. Click on the .html file and it should load into a browser automatically.
3. Within your browser, open the .html file by locating the "Open File" option and selecting the .html file.

Notes regarding the resume web page:

This resume was designed to have a header, two columns of content, and a footer. The avatar is dynamic (changing from black and white to colour) and there are several links embedded in the page itself that showcase my work. Please note that my LinkedIn page is not yet set up, hence the link will direct you to the homepage, not my current profile (I am in the process of fixing this). The resume is intended to be responsive to the device it is being accessed with. 

Files included in the LAB1 zip folder:
1. HTML Resume Website (.html file)
2. CSS File 'Lab1'
3. Current .txt file
4. Images used for website under the img folder.
5. HTML Code as a .txt file if required


