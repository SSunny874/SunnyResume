Hello!

The following are instructions on how to open my resume webpage locally:
1. Extract the contents of the zip file into a different folder to view the webpage.
1. Drag and drop the .html file into a web browser of your choice.
2. Click on the .html file and it should load into a browser automatically.
3. Within your browser, open the .html file by locating the "Open File" option and selecting the .html file.

Notes regarding Assignemt 1:

This assignment includes a homepage, main resume page, and a contact page. Please note that for the contact form, a valid phone number, e-mail, and a message with a minimum character length of 40 is required for the form to be submitted. Otherwise, an error message will be displayed. 


Files included in the LAB1 zip folder:
1. Home (home.html)
2. Contact Page (resumecontactpage.html)
3. Resume (SundasShahnawazLab1.html)
4. 2 CSS Files (home and lab1)
5. JavaScript File (assignment1.js)
6. Current .txt file
7. Images used for website under the img folder.
8. Assignment 1 Reflection (PDF)


